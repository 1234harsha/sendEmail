﻿using Microsoft.AspNetCore.Mvc;

namespace SendMail2.Controllers
{
    public class HomeController : Controller
    {
      private readonly IEmailSender _emailSender;

        public HomeController(IEmailSender emailSender)
        {
            _emailSender = emailSender;
        }

     public async Task<IActionResult> Index()
        {
            var reciever = "harshanair113@gmail.com";
            var subject = "test";
            var message = "hello";
            await _emailSender.SendEmailAsync(reciever, subject, message);
            return View();
        }
    }
}
