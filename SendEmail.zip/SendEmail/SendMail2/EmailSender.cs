﻿
using System.Net;
using System.Net.Mail;

namespace SendMail2
{
    public class EmailSender : IEmailSender
    {
        public Task SendEmailAsync(string email, string subject, string message)
        {
            var mail = "harshanair820@gmail.com";
            var pw = "Harsha@0987654321";
            var client = new SmtpClient("smtp.gmail.com", 587)
            {
                EnableSsl = true,
                Credentials = new NetworkCredential(mail, pw)
            };
            return client.SendMailAsync(new MailMessage(from: mail,
                to: email,
                subject,
                message));
        }
    }
}
